
PROJECT WOLF - CLI CORE (Developer Edition)

Files included:
- vaultbreaker.py: Main CLI launcher
- Supports --target and --mode flags
- Modes: stealth, audit, breach

Usage:
    python3 vaultbreaker.py --target 192.168.1.0/24 --mode stealth
